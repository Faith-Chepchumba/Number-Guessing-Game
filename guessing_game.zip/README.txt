# Number Guessing Game

## Overview

A command-line game where users guess a randomly generated number.

## Features

- Provides feedback on guesses (too high, too low).
- Tracks number of attempts.

## Technologies Used

- Python

## How to Run

1. Run the script: `python guessing_game.py`